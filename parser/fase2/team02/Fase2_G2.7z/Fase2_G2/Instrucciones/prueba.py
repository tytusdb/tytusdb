#-------------------------------
print("FUNCTION BINARYSTRING")
#import FunctionBinaryString.Convert
from Instrucciones.FunctionBinaryString.Decode import *
'''
import FunctionBinaryString.Decode
import FunctionBinaryString.Encode
import FunctionBinaryString.GetByte
import FunctionBinaryString.Length
import FunctionBinaryString.Md5
#import FunctionBinaryString.SetByte
import FunctionBinaryString.Sha256
#import FunctionBinaryString.Substr
import FunctionBinaryString.Substring
import FunctionBinaryString.Trim

#-------------------------------
print("FUNCTION MATHEMATIC")
import FunctionMathematical.Abs
#import FunctionMathematical.Cbrt
import FunctionMathematical.Ceil
import FunctionMathematical.Ceiling
import FunctionMathematical.Degrees
import FunctionMathematical.Factorial
import FunctionMathematical.Floor
import FunctionMathematical.Gcd
#import FunctionMathematical.Lcm
#import FunctionMathematical.Ln
import FunctionMathematical.Log
import FunctionMathematical.Log10
#import FunctionMathematical.MinScale
import FunctionMathematical.Mod
import FunctionMathematical.PI
import FunctionMathematical.Power
import FunctionMathematical.Radians
import FunctionMathematical.Random
import FunctionMathematical.Round
import FunctionMathematical.Scale
#import FunctionMathematical.SetSeed
#import FunctionMathematical.Sign
import FunctionMathematical.Sqrt
#import FunctionMathematical.TrimScale
import FunctionMathematical.Trunc
#import FunctionMathematical.WidthBucket
#-------------------------------
print("FUNCTION TRIGONOMETRIC")
import FunctionTrigonometric.Acos
import FunctionTrigonometric.Acosh
import FunctionTrigonometric.Asin
import FunctionTrigonometric.Asinh
import FunctionTrigonometric.Atan
import FunctionTrigonometric.Atan2
import FunctionTrigonometric.Atanh
import FunctionTrigonometric.Cos
import FunctionTrigonometric.Cosh
import FunctionTrigonometric.Cot
import FunctionTrigonometric.Sin
import FunctionTrigonometric.Sinh
import FunctionTrigonometric.Tan
import FunctionTrigonometric.Tanh
print("hola")
'''