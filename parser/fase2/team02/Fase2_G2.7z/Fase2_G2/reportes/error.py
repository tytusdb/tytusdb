
class Error:
     def __init__(self, TIPO, LEXEMA, FIL, COL):
         self.TIPO = TIPO
         self.LEXEMA = LEXEMA
         self.COL = COL
         self.FIL=FIL
