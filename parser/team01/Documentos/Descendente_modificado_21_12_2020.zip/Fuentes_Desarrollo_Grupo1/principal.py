import ts as TS
import sys
import os
import analizador_sintactico as g
from recorredorAst import recorredorAst
import graficarAST as h
from analizador_lexico import *
from expresiones import *
from instrucciones import *
from Nodo import *


class inicio():
    def __init__(self):
        f = open("./entrada/entrada.txt", "r")
        input = f.read()
        Nodo = g.ejecucion_sintactico(input)
        if Nodo is None:
            print('No hay instrucciones que procesar.')
            pass
        else:
            #ts_global = TS.TablaDeSimbolos()
            #self.procesar_instrucciones(Nodo, ts_global)   
            # recorredor = recorredorAst() #instanciamos nuestro recorredor
            # recorredor.recorrer(Nodo) #recorremos el arbol
            h.recorrer(Nodo)
            


    def procesar_instrucciones(self, instrucciones, ts) :
        for instr in instrucciones :
            print(instr.cad)


#ejecucion principal de la gramatica
inicio()