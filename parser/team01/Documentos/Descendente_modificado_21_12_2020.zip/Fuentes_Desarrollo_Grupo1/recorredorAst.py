
import sys 
  
class recorredorAst:
#Recorre todas las expresiones linea por linea

    def recorrer(self, arbol):
        if arbol is not None:
            for i in range(0,len(arbol)):
                print("--#Previo ingreso a calcular")
                valor = self.calcular(arbol[i])
                print('Sentencia %d: %s \n' % (i,valor))
            #--fin recorrer

    #calcula recursivamente el valor de la expresion definida en arbol
    def calcular(self,arbol):
        print("--#Iniciando calcular")
        # hacemos recorrido post-orden del AST evaluando primero la cantidad de nodos hijos

        # si el nodo no tiene hijos, es nodo de un terminal, por lo que devolvemos su valor
        if arbol.hijos is None or arbol.esHoja == 'S':
            print("["+arbol.lexema+"]")
            return arbol.lexema

        #---------------------------
        # si el nodo tiene 1 hijo, es nodo transitorio, por lo que recursivamente volvemos a llamar a recorrer dentro del nodo hijo
        elif len(arbol.hijos) == 1:
            print("--#Arbol con 1 hijo previo a ingresar a calcular")
            return self.calcular(arbol.hijos[0])
        
        # si el nodo tiene 2 hijos, el nodo es de operacion ^(operador, (valor izquierdo, valor derecho) )
        elif len(arbol.hijos) == 2:
            print("--#Arbol con 2 hijos previo a ingresar a calcular")
            #obtenemos el valor de los nodos hijos
            valor1 = self.calcular(arbol.hijos[0]) #obtenemos valor del nodo izq
            valor2 = self.calcular(arbol.hijos[1]) #obtenemos valor del nodo der
            return str(valor1) +"|"+ str(valor2)
            # si la operacion definida en el nodo es * se multiplican
            # los valores devueltos por el recorrido de los nodos hijos
            # if(arbol.etiqueta == 'insert_columns_and_source'):
            #     print("--#Previo a retornar valores por insert_columns_and_source")
            #     return str(valor1) +str(valor2)
            #     # si la operacion definida en el nodo es / se dividen
            #     # los valores devueltos por el recorrido de los nodos hijos
            # elif(arbol.etiqueta == '/'):
            #     if valor2 == 0:
            #         return valor1 / valor2
            #     else:
            #         raise "division entre 0"
            #         # si la operacion definida en el nodo es + se suman
            #         # los valores devueltos por el recorrido de los nodos hijos
            # elif(arbol.etiqueta == '+'):
            #     return valor1 + valor2
            #         # si la operacion definida en el nodo es - se restan
            #         # los valores devueltos por el recorrido de los nodos hijos
            # elif(arbol.etiqueta == '-'):
            #     return valor1 - valor2
            # else:
            #     #calculamos siempre para el primer hijo en caso que no se especific
            #     print("--#Previo a ingresar a CALCULAR recursivamente")
            #     return self.calcular(arbol.hijos[0])
        #--fin calcular
