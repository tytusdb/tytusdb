from enum import Enum
from collections import defaultdict
from functools import reduce  # forward compatibility for Python 3
import operator



class TIPO_DATO(Enum) :
    NUMERO = 1
    PUNTERO = 2
    ARRAY = 3
    STRUCT = 4
    ETIQUETA = 5

class Simbolo() :
    'Esta clase representa un simbolo dentro de nuestra tabla de simbolos'

    def __init__(self, id, tipo, valor) :
        self.id = id
        self.tipo = tipo
        self.valor = valor


        if tipo == TIPO_DATO.ARRAY :
            self.diccionario = {}
        elif tipo == TIPO_DATO.STRUCT :
            self.diccionarioStruct = []
           

class TablaDeSimbolos() :
    'Esta clase representa la tabla de simbolos'


    def __init__(self, simbolos = {}) :
        self.simbolos = simbolos

    def agregar(self, simbolo) :
        self.simbolos[simbolo.id] = simbolo
    
    def obtener(self, id) :
        if not id in self.simbolos :
            #print('Error: variable ', id, ' no definida.')
            return None
        else :
            return self.simbolos[id]

    def obtenerValorArray(self, id, indice) :
        if not id in self.simbolos :
            print('Error: variable ', id, ' no definida.')
        else :
           return self.simbolos[id].diccionario.get(indice)

    def obtenerValorStruct(self, id, lista) :
        if not id in self.simbolos :
            print('Error: variable ', id, ' no definida.')
            return None            
        else :
            # temList = []
            # for x in lista :
            #     temList.append(x.val)

            for key in self.simbolos[id].diccionarioStruct:
                if key[0] == lista :
                    print(key[1])
                    return key[1]
            return None


    def actualizar(self, simbolo) :
        if not simbolo.id in self.simbolos :
            print('Error: variable ', simbolo.id, ' no definida.')
        else :
            self.simbolos[simbolo.id] = simbolo

    def actualizarArreglo(self, simbolo, indice, valor) :
        if not simbolo.id in self.simbolos :
            print('Error: variable ', simbolo.id, ' no definida.')
        else :
            #1 buscar el simbolo x  actualizar....
            #2 obtener el objeto diccionario del simbolo x
            #3 crear un diccionario con valor e indice
            #r simbolox.diccionario.update(dicActualizado)
            dictemp = {indice.val : valor}
            self.simbolos[simbolo.id].diccionario.update(dictemp)



    def actualizarStruct(self, simbolo, indices, valor) :
        if not simbolo.id in self.simbolos :
            print('Error: variable ', simbolo.id, ' no definida.')
        else :
            
                contadorindex = 0
                existencia = 0
                for key in self.simbolos[simbolo.id].diccionarioStruct:
                    if indices == key[0] :
                        self.simbolos[simbolo.id].diccionarioStruct[contadorindex][1] = valor
                        existencia = existencia + 1
                        break
                    contadorindex = contadorindex +1

                # if indices in self.simbolos[simbolo.id].diccionarioStruct :
                #     #para cada struct 
                #     indices.append(valor)
                #     for key in self.simbolos[simbolo.id].diccionarioStruct:
                #         if key == indices :
                #             self.simbolos[simbolo.id].valor = valor

                if existencia == 0 :
                    tempList = []
                    tempList.append(indices)
                    tempList.append(valor)
                    self.simbolos[simbolo.id].diccionarioStruct.append(tempList)


    
    def eliminar(self, simbolo, val):

        for c,v in self.simbolos.items():
            if v.tipo == TIPO_DATO.PUNTERO :
                if v.valor  == simbolo.id :
                   v.valor = val
                   v.tipo = TIPO_DATO.NUMERO

        del self.simbolos[simbolo.id]


    def retornarReporteSimbolos(self):
        resumen = ''
        tipo = ''
        valor =''
        nombre = ''
        dimension = ''

        resumen= ('Identificador                Tipo                Dimension                Valor         ')
        resumen += "\n"

        for c,v in self.simbolos.items():
            if v.tipo == TIPO_DATO.PUNTERO :
                tipo = 'PUNTERO'
                dimension = 1

            elif v.tipo == TIPO_DATO.ARRAY :
                tipo = 'ARREGLO'
                dimension = len(v.diccionario)

            elif v.tipo == TIPO_DATO.ETIQUETA :
                tipo = 'Func/Proc'
                dimension = ''


            elif v.tipo == TIPO_DATO.NUMERO :
                tipo = 'NUMERICO'
                dimension = 1

            elif v.tipo == TIPO_DATO.STRUCT :
                tipo = 'STRUCT'
                dimension = len(v.diccionarioStruct[0])


            valor = v.valor
            nombre = v.id

            resumen += "\n"
            resumen += "{:16}        {:16}          {:16}         {:16}".format(str(nombre), str(tipo), str(dimension), str(valor))
        #self.home.tx_reporteTablaSimbolos.setText(cadenats)      
        return resumen                   

