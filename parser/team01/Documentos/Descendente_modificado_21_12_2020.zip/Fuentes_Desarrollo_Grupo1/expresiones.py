from enum import Enum

class OPERACION_ARITMETICA(Enum) :
    MAS = 1
    MENOS = 2
    POR = 3
    DIVIDIDO = 4
    RESIDUO = 5
    ABSOLUTO = 6

class OPERACION_LOGICA(Enum) :
    MAYOR_QUE = 1
    MENOR_QUE = 2
    IGUAL = 3
    DIFERENTE = 4
    MAYOR_IGUAL = 5
    MENOR_IGUAL = 6


class OPERACION_BITBIT(Enum):
    NOT = 1
    AND = 2
    OR = 3
    XOR = 4
    SHIFT_IZQ = 5
    SHIFT_DER = 6

class OPERACION_LOG(Enum):
    Not = 1
    And = 2
    Or = 3
    Xor = 4



class ExpresionNumerica:
    '''
        Esta clase representa una expresión numérica
    '''

class Expresion_table(ExpresionNumerica) :
    '''
        Esta clase representa un table
    '''
    def __init__(self, id = "") :
        self.id = id
        if id is None : print("**None Expresion_table**")   


class Expresion_insert_value(ExpresionNumerica) :
    '''
        Esta clase representa una expresión numérica entera o decimal.
    '''

    def __init__(self, val, tipo) :
        self.val = val
        self.tipo = tipo
        if val is None : print("***********777777777**")   