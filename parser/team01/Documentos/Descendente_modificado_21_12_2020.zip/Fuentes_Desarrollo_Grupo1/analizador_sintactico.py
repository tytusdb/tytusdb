import ply.yacc as yacc
import tempfile
from analizador_lexico import tokens
from analizador_lexico import analizador
from Nodo import *
from datetime import datetime
#import storageManager
from storageManager import jsonMode as manager
from expresiones import *
from instrucciones import *
from graphviz import *




# AsociaciÃ³n de operadores y precedencia
# precedence = (
#     ('left','MAS'),
#     ('left','DIVIDIDO'),
#     ('right'),
#     )



nombres = {}
resultado_gramatica = []

dot = Digraph(comment='The Round Table')

i = 0

def inc():
    global i
    i += 1
    return i

# *************************************************
# **********************         init  Modificado 11  de diciembre  Henry , acepta varias sentencias ***********
# *************************************************


def p_init(t):
    '''init : statement_list
    '''
    t[0] = Nodo("init", [t[1]],'N',None)
    
    
    
    # *************************************************
    # *****statement_list NO RECURSIVO ***********
    # *************************************************    
    

def p_statement_list(t):
    '''statement_list : statement statement_list_P
    '''
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("statement_list", temp,'N',None)
  

def p_empty(t):
    'empty : '
    pass
        
    #t[0] = None   
    # t[0] = Nodo("epsilon", [t[1]],'N',None)
    # t[0] = Nodo("epsilon", "epsilon",'S',str('ε'))
    t[0] = Nodo("epsilon", "ε",'S',"ε")
  

def p_statement_list_statement(t):
    '''statement_list_P : statement
                        | empty
    '''
    t[0] = Nodo("statement_list_P", [t[1]],'N',None)
   
   

   
def p_statement(t) :
    '''statement : insert_statement
                 | definitiondb_statement
                 | update_statement
                 | delete_statement
                 | select_statement
                 | enumtype
                 
    '''
    t[0] = Nodo("statement", [t[1]],'N',None)  
    
    

  

    #*************************************************
    #**********************        type enum Modificado 14  de diciembre  Henry    Todas las posibles opcciones   ***********

    #*************************************************     

def p_enumtype(t):
    'enumtype : CREATE TYPE un_idx AS ENUM PARIZQ list_enum PARDER PTCOMA' 
    temp = list() 
    temp.append(t[3]) 
    temp.append(t[7])    
    t[0] = Nodo("enumtype", temp,'N',None)

def p_un_id(t) :
    'enumtype : un_idx'
    t[0] = Nodo("list_enum", [t[1]],'N',None)



    # *************************************************
    # ****list_enum NO RECURSIVO ***********
    # ************************************************* 


def p_list_enum(t):
    'list_enum : otro_id list_enum_P '
  #  'list_enum : list_enum  COMA  otro_id '
    
    temp = list()
    temp.append(t[1]) 
    temp.append(t[2]) 
    t[0] = Nodo("list_enum", temp,'N',None) 
    

def p_empty(t):
    'empty : '
    pass
    t[0] = Nodo("epsilon", "ε",'S',"ε")
    
    
def p_otro_id1(t) :
    'list_enum_P : COMA otro_id list_enum_P'
    temp = list()
    temp.append(t[2]) 
    temp.append(t[3]) 
    t[0] = Nodo("list_enum_P", temp,'N',None)                   
       
   # 'list_enum : otro_id'
   # t[0] = Nodo("list_enum", [t[1]],'N',None)
   
   
def p_list_enum_P(t) :
    'list_enum_P : empty'
    t[0] = Nodo("epsilon", "ε",'S',"ε")

def p_list1_enum(t):
    'otro_id :  CADENACOMSIMPLE ' 
    t[0] = Nodo("otro_id", [t[1]],'S',str(t[1]))

    
    

    # *************************************************
    # **********************         createdb_statement Modificado 14  de diciembre  Henry      ***********
    # *************************************************
def p_definitiondb_statement(t):
    '''definitiondb_statement : create_db 
                              | alter_db  
                              | show_db   
                              | drop_db   
    '''       
    t[0] = Nodo("definitiondb_statement", [t[1]],'N',None)    
    
    
def p_create0_db(t):
    'create_db : CREATE ORH REPLACE DATABASE IF NOTH EXISTS ID PTCOMA'
    t[0] = Nodo("create_db", [t[8]],'S',str(t[8]))    

def p_create1_db(t):
    'create_db : CREATE ORH REPLACE DATABASE IF NOTH EXISTS un_idx createdb_option PTCOMA'
    temp = list()
    temp.append(t[8])   
    temp.append(t[9])    
    t[0] = Nodo("create_db", temp,'N',None)    
    
     
def p_create2_db(t):
    'create_db : CREATE ORH REPLACE DATABASE ID PTCOMA'
    t[0] = Nodo("create_db", [t[5]],'S',str(t[5]))    

def p_create3_db(t):
    'create_db : CREATE ORH REPLACE DATABASE un_idx createdb_option PTCOMA'
    temp = list()
    temp.append(t[5])  
    temp.append(t[6]) 
    t[0] = Nodo("create_db", temp,'N',None)  
    
    
    
def p_create4_db(t):
    'create_db : CREATE DATABASE IF NOTH EXISTS ID PTCOMA'
    t[0] = Nodo("create_db", [t[6]],'S',str(t[6]))    

def p_create5_db(t):
    'create_db : CREATE DATABASE IF NOTH EXISTS un_idx createdb_option PTCOMA'
    temp = list()
    temp.append(t[6]) 
    temp.append(t[7])    
    t[0] = Nodo("create_db", temp,'N',None)     



def p_create6_db(t):
    'create_db : CREATE DATABASE ID PTCOMA'
    t[0] = Nodo("create_db", [t[3]],'S',str(t[3]))

def p_create7_db(t):
    'create_db : CREATE DATABASE un_idx createdb_option PTCOMA'
    temp = list()
    temp.append(t[3])
    temp.append(t[4])
    t[0] = Nodo("create_db", temp,'N',None)
 

    
def p_createdb_option(t): 
    """createdb_option : op_owner_mode
               | op_owner
               | op_mode
    """
    t[0] = Nodo("createdb_option", [t[1]],'N',None)  
   

def p_owner_mode(t): 
    'op_owner_mode : op_owner op_mode ' 
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("op_owner_mode", temp,'N',None)    
    
    
def p_p0_owner(t): 
    'op_owner : OWNER IGUAL ID ' 
    t[0] = Nodo("op_owner", [t[3]],'S',str(t[3]))       

def p_p1_owner(t): 
    'op_owner : OWNER ID ' 
    t[0] = Nodo("op_owner", [t[2]],'S',str(t[2]))   
    
def p_p0_mode(t): 
    'op_mode : MODE IGUAL ENTERO' 
    t[0] = Nodo("op_mode", [t[3]],'S',str(t[3]))   
    
def p_p1_mode(t): 
    'op_mode : MODE ENTERO ' 
    t[0] = Nodo("op_mode", [t[2]],'S',str(t[2]))  

def p_show_db(t):
    'show_db : SHOW DATABASES PTCOMA'
    t[0] = Nodo("show_db", [t[2]],'S',str(t[2]))

def p_alter0_db(t):
    'alter_db : ALTER DATABASE ID OWNER TO ID PTCOMA'
    temp = list()
    temp.append(t[3])
    temp.append(t[6])
    t[0] = Nodo("alter_db", temp,'S',None)      
    
def p_alter1_db(t):
    'alter_db : ALTER DATABASE ID RENAME TO ID PTCOMA'
    temp = list()
    temp.append(t[3])
    temp.append(t[6])
    t[0] = Nodo("alter_db", temp,'S',None)     

def p_drop0_db(t):
    'drop_db : DROP DATABASE IF EXISTS ID PTCOMA'
    t[0] = Nodo("drop_db", [t[5]],'S',str(t[5]))
    
     
def p_drop1_db(t):
    'drop_db : DROP DATABASE ID PTCOMA'
    t[0] = Nodo("drop_db", [t[3]],'S',str(t[3]))


def p_id_createx(t) :
    'create_db : un_idx'
    t[0] = Nodo("create_db", [t[1]],'N',None)

def p_un_idx(t):
    'un_idx :  ID ' 
    t[0] = Nodo("un_idx", [t[1]],'S',str(t[1]))

#*************************************************
#**********************         insert_statement      ***********
#*************************************************   
#region INSERT
def p_insert_statement(t) :
    '''insert_statement : INSERT INTO table_name insert_columns_and_source PTCOMA
    '''
    temp = list()
    temp.append(t[3])
    temp.append(t[4])
    t[0] = Nodo("insert_statement", temp,'N',None)


def p_table_name(t) :
    'table_name : ID '
    t[0] = Nodo("table_name", [t[1]],'S',str(t[1]))


#*************************************************
#**********************         insert_columns_and_source      ***********
#*************************************************    

def p_insert_columns_and_source(t) :
    '''insert_columns_and_source : PARIZQ insert_column_list PARDER VALUES query_expression_insert
                                    | VALUES query_expression_insert
                                    | insert_default_values
    '''
    if (len(t) == 6):
        #t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[2])
        temp.append(t[5])
        t[0] = Nodo("insert_columns_and_source", temp,'N',None)
    elif (len(t)==3):
        #t[0] =InsertValues(t[1],t[2])
        t[0] = Nodo("insert_columns_and_source", [t[2]],'N',None)

    elif (len(t)==2):
        #t[0] =InsertValues(t[1],t[2])
        t[0] = Nodo("insert_columns_and_source", [t[1]],'N',None)


def p_insert_defaul_values(t) :
    'insert_default_values    : DEFAULT VALUES'
    t[0] = Nodo("column_name", [t[1]],'S',str(t[1]))


#*************************************************
#********************** insert_column_list     NO RECURSIVO         ***********
#************************************************* 



def p_insert_column_list(t) :
    'insert_column_list    : column_name insert_column_list_P '
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("insert_column_list1", temp,'N', None)
    
    
def p_insert_column_listP(t) :
    'insert_column_list_P   : COMA column_name insert_column_list_P'
    temp = list()
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("insert_column_list_P", temp,'N', None)    
    
def p_empty(t):
    'empty : '
    pass
    t[0] = Nodo("epsilon", "ε",'S',"ε")    

def p_insert_column_listPP(t) :
    '''insert_column_list_P    :  empty  '''
    t[0] = Nodo("epsilon", "ε",'S',"ε")    

def p_insert_column_name(t) :
    'insert_column_list    : column_name'
    #t[0] = [t[1]]
    t[0] = Nodo("insert_column_list2", [t[1]],'N',None)


def p_column_name(t) :
    'column_name    : ID '
    t[0] = Nodo("column_name", [t[1]],'S',str(t[1]))


#*************************************************
#**********************         query_expression_insert      ***********
#*************************************************

def p_query_expression_insert(t):
    '''query_expression_insert :    insert_list
                        '''
    t[0] = Nodo("query_expression_insert", [t[1]],'N',None)


    # *************************************************
    # ****insert List  NO RECURSIVO ***********
    # ************************************************* 



def p_insert_list(t) :
    'insert_list    :  insert_value_list insert_list_P  '
   # '''insert_list    :  insert_list COMA insert_value_list  '''
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("insert_list2", temp,'N',None)


def p_insert_listP(t) :
    '''insert_list_P    :  COMA insert_value_list insert_list_P  '''
    temp = list()
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("insert_list_P", temp,'N',None)
    
def p_empty(t):
    'empty : '
    pass
    t[0] = Nodo("epsilon", "ε",'S',"ε")    

def p_insert_item(t) :
    '''insert_list_P    :  empty  '''
    t[0] = Nodo("epsilon", "ε",'S',"ε")

def p_insert_value_list(t) :
    '''insert_value_list    : PARIZQ value_list PARDER '''
    t[0] = Nodo("insert_value_list", [t[2]],'N',None)




    
    # *************************************************
    # ****value List  NO RECURSIVO ***********
    # *************************************************     


def p_value_list(t) :
    '''value_list    : insert_value value_list_P'''
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("value_list1", temp,'N',None)

def p_value_listP(t) :
    '''value_list_P    : COMA insert_value value_list_P'''
    temp = list()
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("value_list1", temp,'N',None)
    
def p_empty(t):
    'empty : '
    pass
    t[0] = Nodo("epsilon", "ε",'S',"ε")     

#def p_value_listPP(t) :
 #   '''value_list_P    : empty '''

#    t[0] = Nodo("epsilon", "ε",'S',"ε")


def p_value_listPP(t) :
    '''value_list_P    : empty '''
    t[0] = Nodo("epsilon", "ε",'S',"ε")
  #  t[0] = Nodo("value_list1", [t[1]],'N',None)



def p_valorasign(t):
    '''insert_value : ENTERO
                    | DECIMAL
                    | CADENACOMSIMPLE
                    | DEFAULT
                    | NOW PARIZQ PARDER
    '''
    t[0] = Nodo("insert_value", [t[1]],'S',str(t[1]))

#endregion

#*************************************************
#**********************         update_statement      ***********
#*************************************************   
#region UPDATE
def p_update_statement(t) :
    '''update_statement : UPDATE table_name SET set_clause_list WHERE search_condition PTCOMA
                        | UPDATE table_name SET set_clause_list PTCOMA
    '''
    if (len(t) == 8):
        temp = list()
        temp.append(t[2])
        temp.append(t[4])
        temp.append(t[6])
        t[0] = Nodo("update_statement", temp,'N',None)        
    elif (len(t)==6):
        temp = list()
        temp.append(t[2])
        temp.append(t[4])
        t[0] = Nodo("update_statement", temp,'N',None)


        # *************************************************
        # *****set_Claus_list NO RECURSIVO ***********
        # ************************************************* 




def p_set_clause_list(t) :
    '''set_clause_list  : set_clause set_clause_list_P'''
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("set_clause_list", temp,'N',None)

def p_set_clause_listP(t) :
    '''set_clause_list_P    : COMA set_clause set_clause_list_P'''
    temp = list()
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("set_clause_list", temp,'N',None)


def p_empty(t):
    'empty : '
    pass
    t[0] = Nodo("epsilon", "ε",'S',"ε")  


def p_set_clause_listPP(t) :
    '''set_clause_list_P    : empty'''
    t[0] = Nodo("epsilon", "ε",'S',"ε")



def p_set_clause(t) :
    'set_clause : column_name  IGUAL update_source'
    temp = list()
    temp.append(t[1])
    temp.append(t[3])
    t[0] = Nodo("set_clause", temp,'N',None)

def p_update_source(t) :
    '''update_source : value_expression  
                | NULL 
    '''
    t[0] = Nodo("update_source", [t[1]],'N',None)

# *************************************************
# **********************         delete_statement      ***********
# *************************************************

def p_delete_statement(t):
    '''delete_statement : DELETE FROM table_name_d PTCOMA
                        | DELETE FROM table_name_d WHERE search_condition PTCOMA
    '''
    if (len(t) == 5):
        # t[0] =InsertColumnsValues(t[2],t[5])
        
        t[0] = Nodo("delete_statement", [t[3]], 'N', None)
    elif (len(t) == 7):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[3])
        temp.append(t[5])
        
        t[0] = Nodo("delete_statement", temp, 'N', None)
    


def p_table_name_d(t):
    'table_name_d : ID '
    t[0] = Nodo("table_name_d", [t[1]], 'S', str(t[1]))

# *************************************************
# **********************         select_statement      ***********
# *************************************************

def p_select_statement(t):
    '''select_statement : SELECT select_column_list FROM table_name_s PTCOMA
                        | SELECT select_column_list FROM table_name_s WHERE search_condition PTCOMA
                        | SELECT DISTINCT select_column_list FROM table_name_s PTCOMA
                        | SELECT DISTINCT select_column_list FROM table_name_s WHERE search_condition PTCOMA
    '''
    if (len(t) == 6):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[2])
        temp.append(t[4])
        t[0] = Nodo("select_statement", temp, 'N', None)
    elif (len(t) == 8):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[2])
        temp.append(t[4])
        temp.append(t[6])
        t[0] = Nodo("select_statement", temp, 'N', None)
    elif (len(t) == 7):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[3])
        temp.append(t[5])
        t[0] = Nodo("select_statement", temp, 'N', None)
    elif (len(t) == 9):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[3])
        temp.append(t[5])
        temp.append(t[7])
        t[0] = Nodo("select_statement", temp, 'N', None)


def p_table_name_s(t):
    'table_name_s : ID '
    t[0] = Nodo("table_name_s", [t[1]], 'S', str(t[1]))


# *************************************************
# **********************         select_column_list      ***********
# *************************************************

def p_select_column_list(t):
    'select_column_list    : select_column_list  COMA column_name_select'
    temp = list()
    temp.append(t[1])
    temp.append(t[3])
    t[0] = Nodo("select_column_list1", temp, 'N', None)


def p_select_column_name(t):
    'select_column_list : column_name_select'     
    t[0] = Nodo("select_column_list2", [t[1]], 'N', None)


# def p_column_name_select(t):
#     'column_name_select   : column_funtion_select'
#     # t[0] = Nodo("column_name_select", [t[1]], 'S', str(t[1]))
#     t[0] = Nodo("column_name_select", [t[1]], 'N', None)


def p_column_select(t):
    '''column_name_select    : select_function 
                                | select_function PARIZQ select_function_element PARDER
                                | select_function value_expression
                                | select_function PARIZQ PARDER
                                | select_function PARIZQ column_funtionext_select PARDER
    '''

    if (len(t) == 5):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[1])
        temp.append(t[3])
        t[0] = Nodo("column_name_select", temp, 'N', None)
    elif (len(t) == 2):
        # t[0] =InsertColumnsValues(t[2],t[5])        
        t[0] = Nodo("column_name_select", [t[1]], 'N', None)
    elif (len(t) == 4):
        # t[0] =InsertColumnsValues(t[2],t[5])        
        t[0] = Nodo("column_name_select", [t[1]], 'N', None)
    elif (len(t) == 3):
        # t[0] =InsertColumnsValues(t[2],t[5])
        temp = list()
        temp.append(t[1])
        temp.append(t[2])
        t[0] = Nodo("column_name_select", temp, 'N', None)


def p_select_function(t) :
    '''select_function  : SUM  
                        | COUNT 
                        | NOW
                        | CURRENT_DATE 
                        | CURRENT_TIME 
                        | TIMESTAMP                          
                        | EXTRACT                          
                        | DATE_PART 
                        | MULT 
                        | ID 
                                             
    '''
    t[0] = Nodo("column_name", [t[1]],'S', str(t[1]) )


def p_select_function_element(t) :
    '''select_function_element  : ID
                                | NULL
                                
    '''
    if (len(t) == 2):
        t[0] = Nodo("select_function_element", [t[1]], 'S', str(t[1]))
    else :
        t[0] = Nodo("select_function_element", [t[1]], 'S', 'vacio')


def p_column_functionext_select(t):
    '''column_funtionext_select : column_datefuntion_select 
                                | column_datepartfuntion_select 
    '''
    t[0] = Nodo("column_funtionext_select", [t[1]], 'N', None)

def p_column_datefunction_select(t) :
    '''column_datefuntion_select    : column_dateExtractfunc_select FROM TIMESTAMP  value_expression                  
    '''
    temp = list()
    temp.append(t[1])
    temp.append(t[4])
    t[0] = Nodo("column_datefuntion_select", temp, 'N', None)
    


def p_column_dateExtractfunc_select(t) :
    '''column_dateExtractfunc_select    : HOUR  
                                        | MINUTE 
                                        | SECOND
                                        | YEAR 
                                        | MONTH 
                                        | DAY                          
    '''
    t[0] = Nodo("column_dateExtractfunc_select", [t[1]],'S', str(t[1]) )
   


def p_column_datepartfunction_select(t) :
    '''column_datepartfuntion_select    : column_datepartfunc_select COMA INTERVAL column_datepartfuncDATE_select              
    '''
    temp = list()
    temp.append(t[1])
    temp.append(t[4])
    t[0] = Nodo("column_datefuntion_select", temp, 'N', None)
    


def p_column_datepartfunc_select(t) :
    '''column_datepartfunc_select   : HOURS  
                                    | MINUTES 
                                    | SECONDS                       
    '''
    t[0] = Nodo("column_dateExtractfunc_select", [t[1]],'S', str(t[1]) )
   

def p_column_datepartfuncDATE_select(t) :
    '''column_datepartfuncDATE_select   : ENTERO HOURS    
                                        | ENTERO HOURS ENTERO MINUTES  
                                        | ENTERO HOURS ENTERO MINUTES ENTERO SECONDS                        
    '''
    t[0] = Nodo("column_dateExtractfunc_select", [t[1]],'S', str(t[1]) )




# def p_value_expression_datetime(t):
#     '''value_expression_datetime : ENTERO
#                         | ID
#     '''
#     t[0] = t[1]    

#**********************         search_condition   NO RECURSIVO    ***********
#*************************************************  
def p_search_condition(t) :
    '''search_condition : boolean_factor search_condition_P 
    '''
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    t[0] = Nodo("search_condition", temp,'N',None)

def p_search_conditionP(t) :
    '''search_condition_P : OR boolean_factor search_condition_P                  
    '''
    temp = list()
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("search_conditionP", temp,'N',None)
    
    
def p_search_condition_PP(t) :
    '''search_condition_P : AND boolean_factor search_condition_P                  
    '''
    temp = list()
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("search_conditionP", temp,'N',None)
    
   
   
def p_empty(t):
    'empty : '
    pass
    t[0] = Nodo("epsilon", "ε",'S',"ε")  


def p_search_condition_P_P(t) :
    '''search_condition_P    : empty'''
    t[0] = Nodo("epsilon", "ε",'S',"ε")  
   
   
def p_boolean_factor(t) :
    '''boolean_factor : NOT boolean_test 
                        | boolean_test
    '''
    if (len(t) == 3):
        temp = list()
        temp.append(t[1])
        temp.append(t[2])
        t[0] = Nodo("boolean_factor", temp,'N',None)        
    elif (len(t)==2):
        temp = list()
        temp.append(t[1])
        t[0] = Nodo("boolean_factor", temp,'N',None)
      

#******
    
#-*******************************************************************

def p_boolean_test(t) :
    '''boolean_test : boolean_primary
    '''
    t[0] = Nodo("boolean_test", [t[1]],'N',None)    

def p_boolean_primary(t) :
    '''boolean_primary : predicate
                        |  PARIZQ search_condition PARDER
    '''
    if (len(t) == 2):
        t[0] = Nodo("boolean_primary", [t[1]],'N',None)         
    elif (len(t)==4):
        t[0] = Nodo("boolean_primary", [t[2]],'N',None) 

def p_predicate(t) :
    '''predicate : comparison_predicate
                | between_predicate
                | in_predicate
                | like_percent_predicate
                | null_predicate
    '''
    t[0] = Nodo("predicate", [t[1]],'N',None)  


#*************************************************
#**********************         comparasion           ***********
#*************************************************  

def p_comparison_predicate(t) :
    '''comparison_predicate : row_value_constructor comp_op row_value_constructor
    '''
    temp = list()
    temp.append(t[1])
    temp.append(t[2])
    temp.append(t[3])
    t[0] = Nodo("comparison_predicate", temp,'N',None) 

def p_comp_op(t) :
    '''comp_op : IGUAL
                | MENQUE MAYQUE
                | MENQUE 
                | MAYQUE
                | MENORIGU
                | MAYORIGU
    '''
    if (len(t) == 2):
        t[0] = Nodo("comp_op", [t[1]],'S',str(t[1]))         
    elif (len(t)==3):
        temp = list()
        temp.append(t[1])
        temp.append(t[2])
        t[0] = Nodo("comp_op", temp,'N',None)

def p_row_value_constructor(t) :
    '''row_value_constructor : row_value_constructor_element
                                    | PARIZQ row_value_constructor_list PARDER
    '''
    if (len(t) == 2):
        t[0] = Nodo("row_value_constructor", [t[1]],'N',None)       
    elif (len(t)==4):
        t[0] = Nodo("row_value_constructor", [t[2]],'N',None) 

def p_row_value_constructor_list(t) :
    '''row_value_constructor_list : row_value_constructor_list COMA row_value_constructor_element
    '''
    temp = list()
    temp.append(t[1])
    temp.append(t[3])
    t[0] = Nodo("row_value_constructor_list", temp,'N',None)      

def p_row_value_constructor_item(t) :
    '''row_value_constructor_list : row_value_constructor_element
    '''
    t[0] = Nodo("row_value_constructor_list", [t[1]],'N',None)

def p_row_value_constructor_element(t) :
    '''row_value_constructor_element : value_expression
                                    | NULL
    '''
    t[0] = Nodo("row_value_constructor_element", [t[1]],'N',None) 

def p_value_expression(t):
    '''value_expression : ENTERO
                        | DECIMAL
                        | CADENACOMSIMPLE
                        | DEFAULT
                        | ID
                        | NOW PARIZQ PARDER
    '''
    t[0] = Nodo("value_expression", [t[1]],'S',str(t[1])) 

#endregion

#*************************************************
#**********************         BETWEEN PREDICATE           ***********
#*************************************************  

def p_between_predicate(t) :
    '''between_predicate : row_value_constructor NOTH BETWEEN row_value_constructor AND row_value_constructor
                            | row_value_constructor BETWEEN row_value_constructor AND row_value_constructor
    '''
    if (len(t) == 7):
        temp = list()
        temp.append(t[1])
        tempNode1 = Nodo("between_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode1)
        tempNode3 = Nodo("between_predicate", [t[3]],'S',str(t[3]))
        temp.append(tempNode3)
        temp.append(t[4])
        tempNode5 = Nodo("between_predicate", [t[5]],'S',str(t[5]))
        temp.append(tempNode5)
        temp.append(t[6])
        t[0] = Nodo("between_predicate", temp,'N',None)        

    elif (len(t)==6):
        temp = list()
        temp.append(t[1])
        tempNode2 = Nodo("between_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode2)
        temp.append(t[3])
        tempNode4 = Nodo("between_predicate", [t[4]],'S',str(t[4]))
        temp.append(tempNode4)
        temp.append(t[5])
        t[0] = Nodo("between_predicate", temp,'N',None) 

#*************************************************
#**********************         IN PREDICATE           ***********
#*************************************************  

def p_in_predicate(t) :
    '''in_predicate : row_value_constructor NOT IN in_predicate_value
                            | row_value_constructor IN in_predicate_value
    '''
    if (len(t) == 5):
        temp = list()
        temp.append(t[1])
        tempNode1 = Nodo("in_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode1)
        tempNode3 = Nodo("in_predicate", [t[3]],'S',str(t[3]))
        temp.append(tempNode3)
        temp.append(t[4])
        t[0] = Nodo("in_predicate", temp,'N',None)        

    elif (len(t)==4):
        temp = list()
        temp.append(t[1])
        tempNode2 = Nodo("in_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode2)
        temp.append(t[3])
        t[0] = Nodo("in_predicate", temp,'N',None) 


def p_in_predicate_value(t) :
    '''in_predicate_value : PARIZQ in_value_list PARDER
    '''
    t[0] = Nodo("in_predicate_value", [t[2]],'N',None)


def p_in_value_list(t) :
    '''in_value_list    : in_value_list  COMA value_expression'''
    temp = list()
    temp.append(t[1])
    temp.append(t[3])
    t[0] = Nodo("in_value_list", temp,'N',None)


def p_in_value_item(t) :
    '''in_value_list    : value_expression'''
    t[0] = Nodo("in_value_list", [t[1]],'N',None)


#*************************************************
#**********************         LIKE PREDICATE         ***********
#*************************************************  

def p_like_percent_predicate(t) :
    '''like_percent_predicate : ID NOT LIKE CADENACOMSIMPLE
                        | ID LIKE CADENACOMSIMPLE
    '''
    if (len(t) == 5):
        temp = list()
        temp.append(t[1])
        temp.append(t[2])
        temp.append(t[3])
        temp.append(t[4])
        t[0] = Nodo("like_percent_predicate", temp,'S',None)        
    elif (len(t)==4):
        temp = list()
        temp.append(t[1])
        temp.append(t[2])
        temp.append(t[3])
        t[0] = Nodo("like_percent_predicate", temp,'S',None)



#*************************************************
#**********************         NULL PREDICATE           ***********
#*************************************************  

def p_null_predicate(t) :
    '''null_predicate : row_value_constructor IS NOTH NULL
                        | row_value_constructor IS NULL
                        | row_value_constructor ISNULL
    '''
                        #| row_value_constructor NOTNULL
    if (len(t) == 5):
        temp = list()
        temp.append(t[1])
        tempNode2 = Nodo("null_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode2)
        tempNode3 = Nodo("null_predicate", [t[3]],'S',str(t[3]))
        temp.append(tempNode3)
        tempNode4 = Nodo("null_predicate", [t[4]],'S',str(t[4]))
        temp.append(tempNode4)
        t[0] = Nodo("null_predicate", temp,'N',None)        
    elif (len(t)==4):
        temp = list()
        temp.append(t[1])
        tempNode2 = Nodo("null_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode2)
        tempNode3 = Nodo("null_predicate", [t[3]],'S',str(t[3]))
        temp.append(tempNode3)
        t[0] = Nodo("null_predicate", temp,'N',None)   
    elif (len(t)==3):
        temp = list()
        temp.append(t[1])
        tempNode2 = Nodo("null_predicate", [t[2]],'S',str(t[2]))
        temp.append(tempNode2)
        t[0] = Nodo("null_predicate", temp,'N',None)              

#*************************************************
#**********************         Error           ***********
#*************************************************  

def p_error(t):
    global resultado_gramatica
    if t:
        resultado = "Error sintactico de tipo {} en el valor {} ".format( str(t.type),str(t.value))
        print(resultado)
    else:
        resultado = "Error sintactico {}".format(t)
        print(resultado)
    resultado_gramatica.append(resultado)
 

#*************************************************
#**********************               ***********
#*************************************************   

# Build the parser
parser = yacc.yacc()

def ejecucion_sintactico(data):
    global resultado_gramatica
    resultado_gramatica.clear()
    gram = parser.parse(data)
    if gram:
        now = datetime.now()
        # dd/mm/YY H:M:S
        dt_string = now.strftime("%d_%m_%Y %H_%M_%S")
        print(dot.source)
        dot.attr(splines='false')
        dot.node_attr.update(shape='circle',fontname='arial',color='blue4',fontcolor='blue4')
        dot.edge_attr.update(color='blue4')
        dot.render('.\\tempPDF\\'+dt_string+'.gv', view=False)  # doctest: +SKIP
        '.\\tempPDF\\'+dt_string+'.gv.pdf'


        resultado_gramatica.append(gram)
    else: print("vacio")

    return(resultado_gramatica)
