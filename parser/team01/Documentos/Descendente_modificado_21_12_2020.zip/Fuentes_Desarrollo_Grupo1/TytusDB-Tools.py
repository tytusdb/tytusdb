import tkinter as tk
from io import open
from tkinter import *
from tkinter import filedialog as FileDialog
import principal as gui
from tabulate import tabulate


table = [[1,"Henry","Fajardo",2],[2,"David","Castro",2],[3,"Haroldo","Areas",1],[4,"Pablo","Guerra",4]]
headers=["id_usuario","Nombre", "Apellido","id_pais"]

table1 = [[1,"Mexico"],[2,"Guatemala"],[3,"Colombia"],[4,"Venezuela"]]
headers1=["id_pais","Nombre"]


class ScrollText(tk.Frame):
    def __init__(self, master, *args, **kwargs):
        tk.Frame.__init__(self, *args, **kwargs)
        self.text = tk.Text(self, bg='white', foreground="#2b2b2b", 
                            insertbackground='#2b2b2b',
                            selectbackground="#2b2b2b", width=200, height=23)

        self.scrollbar = tk.Scrollbar(self, orient=tk.VERTICAL, command=self.text.yview)
        self.text.configure(yscrollcommand=self.scrollbar.set)

        self.numberLines = TextLineNumbers(self, width=40, bg=self.cget('bg'))
        self.numberLines.attach(self.text)

        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.numberLines.pack(side=tk.LEFT, fill=tk.Y, padx=(5, 0))
        self.text.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.text.bind("<Key>", self.onPressDelay)
        self.text.bind("<Button-1>", self.numberLines.redraw)
        self.scrollbar.bind("<Button-1>", self.onScrollPress)
        self.text.bind("<MouseWheel>", self.onPressDelay)
    
    def onScrollPress(self, *args):
        self.scrollbar.bind("<B1-Motion>", self.numberLines.redraw)

    def onScrollRelease(self, *args):
        self.scrollbar.unbind("<B1-Motion>", self.numberLines.redraw)

    def onPressDelay(self, *args):
        self.after(2, self.numberLines.redraw)

    def get(self, *args, **kwargs):
        return self.text.get(*args, **kwargs)

    def insert(self, *args, **kwargs):
        return self.text.insert(*args, **kwargs)

    def delete(self, *args, **kwargs):
        return self.text.delete(*args, **kwargs)

    def index(self, *args, **kwargs):
        return self.text.index(*args, **kwargs)

    def redraw(self):
        self.numberLines.redraw()
        
    
class TextLineNumbers(tk.Canvas):
    def __init__(self, *args, **kwargs):
        tk.Canvas.__init__(self, *args, **kwargs, highlightthickness=0)
        self.textwidget = None

    def attach(self, text_widget):
        self.textwidget = text_widget

    def redraw(self, *args):
        '''redraw line numbers'''
        self.delete("all")

        i = self.textwidget.index("@0,0")
        while True :
            dline= self.textwidget.dlineinfo(i)
            if dline is None: break
            y = dline[1]
            linenum = str(i).split(".")[0]
            self.create_text(2, y, anchor="nw", text=linenum, fill="black")
            i = self.textwidget.index("%s+1line" % i)



if __name__ == '__main__':
    Frame = tk.Tk()
    Frame.title("TytusDB")
    pgAdmin = ScrollText(Frame)#AQUIIIIIIIIIIIII ESTA EL CODIGO QUE CARGAMOS
    ruta=""
    Consola = tk.Frame(Frame,  bg = "green", borderwidth=2)
    Consola.place(x = 43,y = 380,width=1325,height=290) 
    text1 = tk.Text(Consola,bg="black", fg="white", 
                        insertbackground='#2b2b2b',
                        selectbackground="#2b2b2b", width=210, height=10) #ESTA ES LA CONSOLA

    scrollbar1 = tk.Scrollbar(Consola, orient=tk.VERTICAL, command=text1.yview)
    text1.configure(yscrollcommand=scrollbar1.set)
    scrollbar1.pack(side=tk.RIGHT, fill=tk.Y)
    text1.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)    


    pgAdmin.pack()
    pgAdmin.text.focus()
    Frame.after(200, pgAdmin.redraw())
    #METODOS
    def TytusDB_Ejecutar(entrada):
        try:
            #Enviamos a ejecutar LA CLASE PRINCIPAL QUE AGREGO DAVID 
            gui.inicio(entrada)         
            
            text1.insert(END, "Tabla Usuarios\n")                   
            text1.insert(END, tabulate(table, headers, tablefmt="psql"))
            text1.insert(END, "\n")
            text1.insert(END, "Tabla Pais\n")                    
            text1.insert(END, tabulate(table1, headers1, tablefmt="psql"))
            text1.insert(END, "\n")            
            
            
        except EOFError:
            print ("Error")  
            
    def abrir():
    
        # Indicamos que la ruta es respecto a la variable global
        # Debemos de forzar esta lectura global porque los comandos
        # sólo son conscientes de las variables externas que son widgets 
        global ruta 
    
        #mensaje.set('Abrir fichero')
    
        ruta = FileDialog.askopenfilename(
            initialdir='.',
            filetypes=(  # Es una tupla con un elemento
                ("Ficheros de texto", "*.txt"),  
            ), 
            title="Abrir un fichero."
        )
    
        # Si la ruta es válida abrimos el contenido en lectura
        if ruta != "":  
            fichero = open(ruta, 'r')
            contenido = fichero.read()
            pgAdmin.delete('1.0', 'end')           # Nos aseguramos de que esté vacío
            pgAdmin.insert('insert', contenido)  # Le insertamos el contenido
            fichero.close()                    # Cerramos el fichero
            Frame.title(ruta + " - TytusDB")  # Cambiamos el título    
    
    # Menú superior
    menubar = tk.Menu(Frame)
    filemenu = tk.Menu(menubar, tearoff=0)
    filemenu.add_command(label="Nuevo")
    filemenu.add_command(label="Abrir",command=lambda:abrir())
    filemenu.add_command(label="Guardar")
    filemenu.add_command(label="Guardar como")
    filemenu.add_separator()
    filemenu.add_command(label="Salir", command=Frame.quit)
    menubar.add_cascade(label="Archivo", menu=filemenu)
    
    Menuejecutar = tk.Menu(menubar, tearoff=0)
    Menuejecutar.add_command(label="Ejecutar",command=lambda: TytusDB_Ejecutar(pgAdmin.get('1.0','end'))) 
    menubar.add_cascade(label="Ejecutar", menu=Menuejecutar)
    
    Menureportes = tk.Menu(menubar, tearoff=0)
    Menureportes.add_command(label="Lexico") 
    Menureportes.add_command(label="Sintactico") 
    Menureportes.add_command(label="Semantico") 
    Menureportes.add_command(label="AST") 

    Menureportes.add_command(label="Tabla simbolos") 
    menubar.add_cascade(label="Reportes", menu= Menureportes)    
    
    Frame.config(menu=menubar)  
 
    Frame.mainloop()
