class Instruccion:
    '''This is an abstract class'''

class Insert:
    '''
        Esta clase representa la accion Insert.
        Recibe como parámetros el nombre de la tabla 
    '''
    def __init__(self, expLogica, instrucciones = []) :
        self.expLogica = expLogica
        self.instrucciones = instrucciones



class DefinicionEtiqueta(Instruccion) :
    '''
        Esta clase representa la instrucción de definición de variables de tipo arreglo.
        Recibe como parámetro el nombre del identificador a definir
    '''

    def __init__(self, id) :
        self.id = id

class InsertColumnsValues(Instruccion) :
    '''
        Esta clase representa la instrucción imprimir.
        La instrucción imprimir únicamente tiene como parámetro una cadena
    '''

    def __init__(self, cad1, ColumnsValues = []) :
        #self.cad1 = cad1
        listacad = []
        for key in cad1: 
            listacad.append(key.id)
        self.cad1 = listacad               

        lista = []
        for key in ColumnsValues[0][0][0] : 
            lista.append(key.val)
        self.ColumnsValues = lista   

class InsertValues(Instruccion) :
    '''
        Esta clase representa la instrucción imprimir.
        La instrucción imprimir únicamente tiene como parámetro una cadena
    '''

    def __init__(self, cad2, ColumnsValues = []) :
        self.cad2 = cad2
        lista = []
        for key in ColumnsValues[0] : 
            lista.append(key.val)
        self.ColumnsValues = lista   


class InstruccionConError(Instruccion) :
    '''
        Recibe como parámetro el nombre error
    '''

    def __init__(self, cad3) :
        self.cad3 = cad3


class InstruccionInsertStatement(Instruccion) : 
    '''
        Esta clase representa la instrucción insert statement
        La instrucción if-else recibe como parámetro una expresión lógica y la lista
        de instrucciones a ejecutar si la expresión lógica es verdadera y otro lista de instrucciones
        a ejecutar si la expresión lógica es falsa.
    '''

    def __init__(self, expTable, instrColumSource = []) :
        self.expLogica = expTable
        self.instrColumSource = instrColumSource

